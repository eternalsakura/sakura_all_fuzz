import struct

def read(name):
    with open(name,'rb') as f:
        return f.read()

def u32(data):
    return struct.unpack("I", data)[0]

def p32(num):
    return struct.pack("I", num)

from unicorn import *
from unicorn.x86_const import *

mu = Uc(UC_ARCH_X86, UC_MODE_32)
BASE = 0x8048000
STACK_ADDR = 0x0
STACK_SIZE = 1024*1024
mu.mem_map(BASE, 1024*1024)
mu.mem_map(STACK_ADDR, STACK_SIZE)
string_addr = 0x0
mu.mem_write(string_addr, b"batman\x00")
str = mu.mem_read(string_addr,6)
print(str)
mu.mem_write(BASE, read("./function"))
mu.reg_write(UC_X86_REG_ESP, STACK_ADDR + 1024)
mu.mem_write(STACK_ADDR + 1024 + 4, p32(5))
mu.mem_write(STACK_ADDR + 1024 + 8, p32(string_addr))
def hook_code(mu, address, size, user_data):
    print
    ('>>> Tracing instruction at 0x%x, instruction size = 0x%x' %(address, size))
    print(mu.mem_read(address,size))

mu.hook_add(UC_HOOK_CODE, hook_code)
mu.emu_start(BASE+0x57b,BASE+0x5b1)
reg = mu.reg_read(UC_X86_REG_EAX)
print(reg)
