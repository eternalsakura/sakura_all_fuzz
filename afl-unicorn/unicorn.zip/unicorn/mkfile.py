# -*- coding: utf-8 -*-

import os, random

def main():
    for i in range(50):
        size = random.randint(20, 50)
        os.system(f'dd if=/dev/urandom of=testcase/testcase_{i} count=2 bs={size}')

if __name__ == '__main__':
    main()

